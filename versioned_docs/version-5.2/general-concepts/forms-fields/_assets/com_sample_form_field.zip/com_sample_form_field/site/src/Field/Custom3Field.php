<?php

namespace Mycompany\Component\Sampleff\Site\Field;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Form\Field\ListField;

/**
 * Form Field class for capturing IATA airport code
 * This approach extends ListField and overrides getOptions
 */
class Custom3Field extends ListField
{
    public function getOptions()
    {
        
		$options  = array("BFS", "HND", "YYZ");

		$options = array_merge(parent::getOptions(), $options);

		return $options;
    }
}