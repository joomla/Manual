<?php

namespace Mycompany\Component\Sampleff\Site\Field;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Form\FormField;

/**
 * Form Field class for capturing IATA airport code
 * This approach uses a layout for the html <input> element
 */
class Custom2Field extends FormField
{
    protected $layout = 'custom2field';
}