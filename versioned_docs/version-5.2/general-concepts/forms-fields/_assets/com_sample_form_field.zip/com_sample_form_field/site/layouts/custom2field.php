<?php

defined('_JEXEC') or die;

extract($displayData);

?>
<input 
    type='text' 
    id='<?php echo $id?>' 
    name='<?php echo $name?>' 
    minlength='3' 
    maxlength='3' 
    size='3'
    oninput='this.value = this.value.toUpperCase()'/>