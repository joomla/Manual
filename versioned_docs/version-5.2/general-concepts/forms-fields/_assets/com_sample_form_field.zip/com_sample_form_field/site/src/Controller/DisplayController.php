<?php

namespace Mycompany\Component\Sampleff\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController {
    
    public function display($cachable = false, $urlparams = array())
    {
        /* Create the $model and $view the parameter 'sample' 
         * The parameter 'sample' indicates the Fully Qualified Name (FQN) 
         * which the Model and View must have. 
         * In other words, Joomla uses this 'sample' string as part of 
         * working out what the FQNs of the Model and View classes are. 
         * (These two class instances actually get created by the MVCFactory 
         * class object which was included via the services/provider.php file.)
         */
        $model = $this->getModel('sample');
        $view = $this->getView('sample', 'html');
        /* Make the Model available to the View code, 
         * with true being passed to indicate that it's 
         * the default Model for the View.
         */
        $view->setModel($model, true);
        $view->display();
    }
}