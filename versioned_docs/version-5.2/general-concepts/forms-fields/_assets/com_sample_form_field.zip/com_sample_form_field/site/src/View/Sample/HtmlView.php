<?php

namespace Mycompany\Component\Sampleff\Site\View\Sample;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;

class HtmlView extends BaseHtmlView
{
    public function display($tpl = null)
	{
        // check if there's any POST data from the previous form submission
        $this->postdata = Factory::getApplication()->getUserState('com_sample_form_field.post', null);
        // and clear it, ready for the next submission
        Factory::getApplication()->setUserState('com_sample_form_field.post', array());
        
        $this->form = $this->getModel()->getForm();
        
        parent::display($tpl);  // will run the tmpl/sample/default.php file
    }
}
