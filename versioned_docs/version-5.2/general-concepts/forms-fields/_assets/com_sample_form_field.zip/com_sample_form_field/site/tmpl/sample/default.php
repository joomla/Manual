<?php
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;

Factory::getApplication()->getDocument()->getWebAssetManager()->useScript('form.validate');

// Display the data from the last form submission (sent in the last HTTP POST request)
if ($this->postdata) {
    ob_start();
    var_dump($this->postdata);
    $post = ob_get_contents();
    ob_end_clean();
}

?>

<?php if ($this->postdata) : ?>
    <h3>Unvalidated data received from last form submission</h3>
    <?php echo '<pre>' . htmlspecialchars($post, ENT_QUOTES) . '</pre>'; ?>
<?php endif; ?>

<form action="<?php echo Route::_('index.php?option=com_sample_form_field'); ?>"
    method="post" name="adminForm" class="form-validate" id="adminForm" enctype="multipart/form-data">

	<?php echo $this->form->renderFieldset('myset');  ?>

	<button type="button" class="btn btn-primary" onclick="Joomla.submitbutton('post.submit')">Submit</button>

	<input type="hidden" name="task" />
	<?php echo HtmlHelper::_('form.token'); ?>
</form>