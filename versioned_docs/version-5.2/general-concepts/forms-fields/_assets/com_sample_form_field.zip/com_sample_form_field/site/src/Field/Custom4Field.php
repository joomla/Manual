<?php

namespace Mycompany\Component\Sampleff\Site\Field;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Form\Field\GroupedlistField;

/**
 * Form Field class for capturing IATA airport code
 * This approach extends GroupedlistField and overrides getGroups
 */
class Custom4Field extends GroupedlistField
{
    public function getGroups()
    {
        
		$groups['Japan'] = array("HND");
        $groups['Canada'] = array("YYC", "YYT", "YYZ");
        $groups['Northern Ireland'] = array("BFS", "BHD");
        
		$groups = array_merge(parent::getGroups(), $groups);

		return $groups;
    }
}