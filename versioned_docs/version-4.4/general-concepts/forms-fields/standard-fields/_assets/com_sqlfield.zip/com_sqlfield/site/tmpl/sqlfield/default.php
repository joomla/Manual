<?php
defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->useScript('form.validate');
$wa->useScript('com_sqlfield.reload');

?>
<form action="<?php echo Route::_('index.php?option=com_sqlfield'); ?>"
    class="form-validate" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

    <?php echo $this->form->renderFieldset('mainFieldset');  ?>

    <button type="button" class="btn btn-primary" onclick="Joomla.submitbutton('sqlfield.submit')">Submit</button>

    <input type="hidden" name="task" />
    <?php echo HtmlHelper::_('form.token'); ?>
</form>