function categoryReload(element) {
    document.body.appendChild(document.createElement('joomla-core-loader'));
    Joomla.submitform(`sqlfield.reload`, element.form, false);
}