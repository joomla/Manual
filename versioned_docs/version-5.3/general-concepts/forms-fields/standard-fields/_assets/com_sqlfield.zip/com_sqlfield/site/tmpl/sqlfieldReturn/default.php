<?php
defined('_JEXEC') or die;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;
?>

<h2>Form Data</h2>

<p>You selected category id <?php echo $this->validatedData["catid"]; ?> and article id <?php echo $this->validatedData["article"]; ?> </p>

<br/>

<a href="<?php echo Route::_('index.php?option=com_sqlfield'); ?>">Return to form</a>
