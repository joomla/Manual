<?php

namespace My\Component\Sqlfield\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController {
    
    public function display($cachable = false, $urlparams = array())
    {
        $model = $this->getModel('sqlfield');

        $view = $this->getView('sqlfield', 'html');

        $view->setModel($model, true);
        
        $view->display();
    }
}