<?php

namespace My\Module\Curtime\Site\Dispatcher;

\defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\DispatcherInterface;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\Input\Input;

class Dispatcher implements DispatcherInterface
{
    public function dispatch()
    {
        echo date("H:i:s");
    }
}