<?php

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use My\Plugin\Ajax\AjaxJobs\Extension\Jobs;

    return new class() implements ServiceProviderInterface
    {
        public function register(Container $container)
        {
            $container->set(
                PluginInterface::class,
                $container->lazy(Jobs::class, 
                                function (Container $container) {
                    
                                    $config = (array) PluginHelper::getPlugin('ajax', 'jobs');
                                    $plugin = new Jobs($config);
                    
                                    return $plugin;
                                }
                            )
            );
        }
    };