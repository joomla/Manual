<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

Factory::getApplication()->getDocument()->getWebAssetManager()->useScript('form.validate');

?>
<h2>Send Mail</h2>
<form action="<?php echo Route::_('index.php?option=com_sendmail&view=mailform'); ?>"
    method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">

    <div class="form-horizontal">
        <fieldset class="adminform">
            <div class="row-fluid">
                <div class="span12">
                    <?php echo $this->form->renderFieldset('details');  ?>
                </div>
            </div>
        </fieldset>
    </div>

    <div class="btn-toolbar">
        <div class="btn-group">
            <button type="button" class="btn btn-primary" onclick="Joomla.submitbutton('mailer.send')">
                <span class="icon-ok"></span>&nbsp;Send
            </button>
        </div>
        <div class="btn-group">
            <button type="button" class="btn" onclick="Joomla.submitbutton('mailer.cancel')">
                <span class="icon-cancel"></span>&nbsp;Cancel
            </button>
        </div>
    </div>

    <input type="hidden" name="task" />
    <?php echo HTMLHelper::_('form.token'); ?>
</form>