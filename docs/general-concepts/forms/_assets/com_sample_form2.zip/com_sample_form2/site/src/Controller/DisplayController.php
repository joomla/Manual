<?php

namespace Mycompany\Component\SampleForm2\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController {
    
    public function display($cachable = false, $urlparams = array())
    {
        $model = $this->getModel('sample');
        $view = $this->getView('sample', 'html');
        $view->setModel($model, true);
        $view->display();
    }
}