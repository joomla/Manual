<?php
namespace Mycompany\Component\SampleForm1\Site\Extension;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Joomla\CMS\Dispatcher\DispatcherInterface;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Form\FormFactoryInterface;
use Joomla\Input\Input;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

class SampleFormComponent implements ComponentInterface, ComponentDispatcherFactoryInterface, DispatcherInterface
{
    public function getDispatcher(CMSApplicationInterface $application): DispatcherInterface
    {
        return $this;
    }
    
    public function createDispatcher(CMSApplicationInterface $application, Input $input = null): DispatcherInterface
    {
        return $this;
    }
    
    public function dispatch()
    {
        $form = Factory::getContainer()->get(FormFactoryInterface::class)->createForm("sample", array("control" => "myform"));
        $formDirectory = JPATH_SITE . '/components/com_sample_form1/forms';
        $form->loadFile($formDirectory . "/sample_form.xml");
        
        $prefillData = array("email" => ".@.");

        if ($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            $app   = Factory::getApplication();
            $data = $app->input->post->get('myform', array(), "array");
            echo "Message was " . $data["message"] .
                ", email was " . $data["email"] .
                ", and telephone was " . $data["telephone"] . "<br>";
            $filteredData = $form->filter($data);
            $result = $form->validate($filteredData);
            if ($result)
            {
                echo "Validation passed ok<br>";
            }
            else
            {
                echo "Validation failed<br>";
                $errors = $form->getErrors();
                foreach ($errors as $error)
                {
                    echo $error->getMessage() . "<br>";
                }
                // in the redisplayed form show what the user entered (after data is filtered)
                $prefillData = $filteredData;
            }
        }

        $form->bind($prefillData);
        ?>
        <form action="<?php echo Route::_('index.php?option=com_sample_form1'); ?>"
            method="post" name="sampleForm" id="adminForm" enctype="multipart/form-data">

            <?php echo $form->renderField('message');  ?>

            <?php echo $form->renderField('email');  ?>

            <?php echo $form->renderField('telephone');  ?>

            <button type="submit">Submit</button>
        </form>
        <?php
    }
}