<?php
defined('_JEXEC') or die('Restricted access');
 
class JFormRuleNoasterisk extends JFormRule
{
	// regex to allow anything except an asterisk
	protected $regex = '^[^\*]+$';
}