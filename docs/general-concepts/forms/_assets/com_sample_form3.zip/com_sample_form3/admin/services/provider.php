<?php
defined('_JEXEC') or die;

use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Mycompany\Component\SampleForm3\Site\Extension\SampleFormComponent;

return new class implements ServiceProviderInterface {
    public function register(Container $container): void 
    {
        $container->set(
            ComponentInterface::class,
            function (Container $container) {
                return new SampleFormComponent();
            }
        );
    }
};